# =======================================================================================================
# ------------------ Questo file rappresenta le chiamate che l'app principale può fare ------------------ 
# =======================================================================================================

import requests

# Questa stringa serve ad Andrea per avviare il file
# & "c:\Users\A1628apulia\Desktop\Progetti Python\.venv\Scripts\python.exe" "c:/Users/A1628apulia/Desktop/Progetti Python/LIS/LIS.py"

# Chiamata all'endpoint dall'esterno
response = requests.get("http://127.0.0.1:8000/ai/test")

# Estrae la risposta JSON
dati = response.json()

print(dati["status"])   # Stampa: ok
print(dati["message"])  # Stampa: API di test funzionante!



# L'URL del tuo nodo esposto
url = "http://127.0.0.1:8000/ai/generate"

# I dati da inviare
payload = {
    "prompt": "Dimmi tre motivi per cui Python è molto usato nel backend.",
    "system_prompt": "Sei un senior software engineer. Rispondi con un elenco puntato breve."
}

# Invia la richiesta al tuo server
response = requests.post(url, json=payload)

# Legge la risposta
if response.status_code == 200:
    data = response.json()
    print("Stato:", data["status"])
    print("Risposta LLM:\n", data["result"])
else:
    print("Errore:", response.json())